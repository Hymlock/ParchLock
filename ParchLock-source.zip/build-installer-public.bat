@echo off
rem ParchLock Windows Setup.exe (NSIS). Public dist (releasable stories).
rem Requires: ParchLock-dist-public from build-android-public.bat with correct public APK.
rem Eamon .eamon is NOT included — separate download.
setlocal EnableExtensions
cd /d "%~dp0"
if "%MAKENSIS%"=="" set "MAKENSIS=C:\Users\hymlo\Downloads\Projects\Tools\nsis-3.13\makensis.exe"
if not exist "%MAKENSIS%" (echo makensis.exe not found: "%MAKENSIS%" & exit /b 1)

set "VER=2.0.102"
if not "%~1"=="" set "VER=%~1"
set "SRC=C:\Users\hymlo\Downloads\ParchLock-dist-public"
set "OUT=C:\Users\hymlo\Downloads\ParchLock-Setup-%VER%-public.exe"

if not exist "%SRC%\ParchLock.exe" (echo ERROR: missing "%SRC%\ParchLock.exe" — build the public dist first. & exit /b 1)
if not exist "%SRC%\ParchLock.apk" (
  if exist "%SRC%\ParchLock-public.apk" (
    copy /y "%SRC%\ParchLock-public.apk" "%SRC%\ParchLock.apk" >nul
  ) else (
    echo ERROR: missing public APK in "%SRC%"
    exit /b 1
  )
)
if not exist "%SRC%\play.html" (echo ERROR: incomplete public dist at "%SRC%" & exit /b 1)

echo Building PUBLIC installer %VER% from %SRC%
"%MAKENSIS%" /V2 /DVERSION=%VER% /DSRC=%SRC% /DOUTFILE=%OUT% /DVARIANT=public installer\parchlock.nsi || exit /b 1
echo Done: "%OUT%"
endlocal
