@echo off
rem ParchLock Windows Setup.exe (NSIS). Private/full dist.
rem Requires: ParchLock-dist already built (build-android.bat / make-dist) with ParchLock.exe + APK.
rem Eamon .eamon is NOT included — separate download.
setlocal EnableExtensions
cd /d "%~dp0"
if "%MAKENSIS%"=="" set "MAKENSIS=C:\Users\hymlo\Downloads\Projects\Tools\nsis-3.13\makensis.exe"
if not exist "%MAKENSIS%" (echo makensis.exe not found: "%MAKENSIS%" & exit /b 1)

set "VER=2.0.101"
if not "%~1"=="" set "VER=%~1"
set "SRC=C:\Users\hymlo\Downloads\ParchLock-dist"
set "OUT=C:\Users\hymlo\Downloads\ParchLock-Setup-%VER%.exe"

if not exist "%SRC%\ParchLock.exe" (echo ERROR: missing "%SRC%\ParchLock.exe" — build the private dist first. & exit /b 1)
if not exist "%SRC%\ParchLock.apk" (echo ERROR: missing "%SRC%\ParchLock.apk" — build/copy the private APK first. & exit /b 1)
if not exist "%SRC%\play.html" (echo ERROR: incomplete dist at "%SRC%" & exit /b 1)

echo Building PRIVATE/full installer %VER% from %SRC%
"%MAKENSIS%" /V2 /DVERSION=%VER% /DSRC=%SRC% /DOUTFILE=%OUT% /DVARIANT=full installer\parchlock.nsi || exit /b 1
echo Done: "%OUT%"
endlocal
