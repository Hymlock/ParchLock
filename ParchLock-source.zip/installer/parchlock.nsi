; ParchLock Windows installer (NSIS 3, Modern UI 2).
; Built by build-installer.bat / build-installer-public.bat after the matching dist folder exists.
; Per-user install (no admin) to %LOCALAPPDATA%\Programs\ParchLock.
; Does NOT bundle the Eamon Showcase .eamon module (separate download).
Unicode true
!include "MUI2.nsh"

!ifndef VERSION
  !define VERSION "2.0.101"
!endif
!ifndef SRC
  !define SRC "C:\Users\hymlo\Downloads\ParchLock-dist"
!endif
!ifndef OUTFILE
  !define OUTFILE "C:\Users\hymlo\Downloads\ParchLock Setup ${VERSION}.exe"
!endif
!ifndef VARIANT
  !define VARIANT "full"
!endif

!define APPNAME "ParchLock"
!define PUBLISHER "Hymlock Groves"
!define COPYRIGHT "ParchLock — GPL-3.0. Based on Parchment/Parchmap."
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\com.parchlock.app"

Name "${APPNAME}"
OutFile "${OUTFILE}"
InstallDir "$LOCALAPPDATA\Programs\${APPNAME}"
InstallDirRegKey HKCU "${UNINST_KEY}" "InstallLocation"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "${PUBLISHER}"

VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "LegalCopyright" "${COPYRIGHT}"
VIAddVersionKey "FileDescription" "${APPNAME} Setup (${VARIANT})"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"

!define MUI_ICON "..\img\favicon.ico"
!define MUI_UNICON "..\img\favicon.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\ParchLock.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Run ${APPNAME}"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "..\LICENSE"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "Install"
  nsExec::Exec 'taskkill /f /im "ParchLock.exe"'
  SetOutPath "$INSTDIR"
  ; Replace prior install payload
  RMDir /r "$INSTDIR"
  SetOutPath "$INSTDIR"
  ; Full dist tree except Eamon module packages (separate download)
  File /r /x ".git" /x ".gitignore" /x "eamon-test" /x "*.eamon" "${SRC}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall ParchLock.exe"
  ; Start Menu only here. Desktop shortcut + rotating scene icons are owned by
  ; ParchLock.exe (D215). A fixed favicon on the desktop would fight that rotation.
  CreateDirectory "$SMPROGRAMS"
  CreateShortCut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\ParchLock.exe" "" "$INSTDIR\img\icons\parchlock-map.ico" 0
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINST_KEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\img\icons\parchlock-map.ico"
  WriteRegStr HKCU "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall ParchLock.exe"'
  WriteRegStr HKCU "${UNINST_KEY}" "QuietUninstallString" '"$INSTDIR\Uninstall ParchLock.exe" /S'
  WriteRegStr HKCU "${UNINST_KEY}" "Comments" "${COPYRIGHT} (${VARIANT})"
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoRepair" 1
SectionEnd

Section "Uninstall"
  nsExec::Exec 'taskkill /f /im "ParchLock.exe"'
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  Delete "$DESKTOP\${APPNAME}.lnk"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "${UNINST_KEY}"
  ; IndexedDB / local data under the browser profile is not removed
SectionEnd
